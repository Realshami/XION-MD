<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=100&pause=1000&color=FF033E&center=true&width=1000&height=200&lines=SENU-MD-BOT" alt="Typing SVG" /></a>
  </p>

<p align="center">
  <h1 align="center">SENU-MD 3.0</h1>
</p>

> **`Updated` The Version 3.0**

---
<p align="center">
  <a href="https://github.com/Awais-star-a11y">
    <img src="http://readme-typing-svg.herokuapp.com?color=FF0000&center=true&vCenter=true&multiline=false&lines=SENU-MD-+v3.0+MultiDevice;Developed+by+SenuMd;Give+star+and+forks+this+Repo+🌟" alt="SENU110Readme">
  </a>
</p>

<a><img src='https://files.catbox.moe/zkv7u1.jpg'/></a>
<h1 align="center"> SENU-MD </h1> 
<p align="center">SENU-MD made for people, on Earth </p>

 
   
<p align="center">
 <h2>WhatsApp channel</h2>
  <a href="https://whatsapp.com/channel/0029Vb2OcviBFLgPzVjWhE0n" target="_blank">
    <img alt="whatsapp" src="https://img.shields.io/badge/ Join Whatsapp Channel For Updates-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
 



<p align="center"> SENU-MD uses
  <a href="https://github.com/WhiskeySockets/Baileys)**">Multi-Device Baileys.</a>
</p>
<p align="center">
  <img title="Whatsapp-Bot-Javascript" src="https://img.shields.io/badge/Javascript-363303?style=for-the-badge&logo=javascript&logoColor=c6c631"></img>
</p>

    

1. Link your WhatsApp by [`PAIR CODE`](https://senu-md-pair-8o5q.onrender.com/)
2. ***Then `Go to Whatapp > Three dots > Linked Devices`***
3. Deploy On Heruku .[`HEROKU`](https://dashboard.heroku.com/new-app?template=https://github.com/Awais-star-a11y/AWAIS-MD-V3)
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
    </tr>
    <tr>
      <td><a href="https://dashboard.render.com/web/new" target="_blank"><img src="https://img.shields.io/badge/Render-000000?style=for-the-badge&logo=render&logoColor=white&labelColor=000000&color=00ffaa"/></a></td>
      <td><a href="https://app.netlify.com/" target="_blank"><img src="https://img.shields.io/badge/Netlify-CC00FF?style=for-the-badge&logo=huggingface&logoColor=white&labelColor=000000"/></a></td>
    </tr>
  </table>
</div>

<table align="center">
  <tr>
    <td>
      <a href="https://whatsapp.com/channel/0029VatOy2EAzNc2WcShQw1j/2303" target="_blank">
        <img alt="View Workflow Codes" src="https://img.shields.io/badge/View-Workflow%20Codes-FF0076?style=for-the-badge&logo=githubactions&logoColor=white"/>
      </a>
    </td>
  </tr>
</table>  

<div align="center">
  <img src="https://github.com/JawadYT36/KHAN-MD/blob/main/assets/techwave.gif?raw=true" width="100%"/>
</div>

## 🌟 BOT FEATURES

```bash
✦ Antidelete, Antiviewonce, Antilink
✦ High speed YT, Tiktok, FB, IG Downloaders
✦ 10+ AI models + Image anlysis AI
✦ Fast low latensie, Powerful
✦ Futuristic Cool ICY UI
```

<div align="center">
  <img src="https://github.com/JawadYT36/KHAN-MD/blob/main/assets/cyberdivider.gif?raw=true" width="100%"/>
</div>

## 🪀  SUPPORT CHANNEL

<div align="center">
  <a href="https://whatsapp.com/channel/0029VazFu9h7dmeQZLEuWB0V/229">
    <img src="https://img.shields.io/badge/Join-WhatsApp%20Channel-25D366?style=for-the-badge&logo=whatsapp&logoColor=white&labelColor=000000"/>
  </a>
</div>

<div align="center">
  <img src="https://github.com/JawadYT36/KHAN-MD/blob/main/assets/neonpulse.gif?raw=true" width="300"/>
</div>

## ⚠️ WARNING !

<div style="background-color: #000000; border-left: 5px solid #ff00ff; padding: 10px; border-radius: 0 15px 15px 0; box-shadow: 0 0 15px #ff00ff;">
  <h3 style="color: #00ffff; font-family: 'Orbitron', sans-serif;">DISCLAIMER</h3>
  <p style="color: #ffffff;">This bot is not affiliated with WhatsApp Inc. Use at your own risk. Misuse may result in account bans.</p>
</div>

<div align="center">
  <img src="https://github.com/JawadYT36/KHAN-MD/blob/main/assets/digitalrain.gif?raw=true" width="100%"/>
</div>

## 🗃️ PROJECT ARCHITECTS
<div align="center">
  <a href="https://github.com/JawadYT36">
    <img src="https://github-readme-stats.vercel.app/api?username=Jester36&show_icons=true&theme=dark&border_color=00ffff&title_color=00ffff&icon_color=00ffff" width="400"/>
  </a>
</div>

<div align="center">
  <img src="https://github.com/JawadYT36/KHAN-MD/blob/main/assets/futuretech.gif?raw=true" width="100%"/>
</div>

## 👑 JESTER STATUS

```diff
+ Project Status: Active
! Version: 5.0.0 Neon Edition
# License: APACHE
```

<div align="center">
  <img src="https://github.com/JawadYT36/KHAN-MD/blob/main/assets/endwave.gif?raw=true" width="100%"/>
</div>
